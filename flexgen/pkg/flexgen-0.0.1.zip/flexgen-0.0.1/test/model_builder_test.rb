require 'model_builder/builder_test'
require 'model_builder/serializer_test'
require 'model_builder/builder_context_test'
require 'model_builder/reference_resolver_test'
